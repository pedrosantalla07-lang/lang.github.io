# reelweather.github.io

GitHub Pages site for the ReelWeather app.

## Files
- `app-ads.txt` — IAB app-ads.txt declaration for ad inventory.
- `index.html` — simple landing page with Play Store link.

## Local testing
- Open `index.html` in a browser.
- Open `app-ads.txt` in a browser to ensure it renders raw text.